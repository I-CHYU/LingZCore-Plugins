"""画画板插件：右侧面板自由绘画，保存为 PNG 或一键添加到对话。"""

import base64
import os
import time

from lingzcore_plugin_api import PluginBase


PLUGIN_ID = "com.yourname.paintboard"
PANEL_NAME = "paintboard"


class Plugin(PluginBase):
    def on_load(self, context):
        self.context = context
        context.register_panel(PANEL_NAME, "画画板", self._panel_factory, position="right")
        context.register_action("save", self._action_save)
        context.register_action("add_to_chat", self._action_add_to_chat)
        context.log("[paintboard] 已加载")

    def on_unload(self):
        try:
            self.context.log("[paintboard] 已卸载")
        except Exception:
            pass

    # ---------- 面板 ----------

    def _panel_factory(self):
        return {"title": "画画板", "html": PANEL_HTML}

    # ---------- 数据处理 ----------

    def _decode_image(self, payload):
        data_url = (payload or {}).get("dataUrl") or ""
        if not data_url.startswith("data:image/"):
            raise ValueError("未收到有效的图片数据")
        try:
            _header, b64 = data_url.split(",", 1)
        except ValueError:
            raise ValueError("图片数据格式错误")
        return base64.b64decode(b64)

    def _output_dir(self):
        try:
            ws = self.context.get_state("current_workspace")
        except Exception:
            ws = None
        if not ws:
            home = os.path.expanduser("~")
            ws = os.path.join(home, ".lingzcore", "plugin_data", PLUGIN_ID)
        return os.path.join(ws, "paintboard")

    def _save_png(self, raw_bytes):
        out_dir = self._output_dir()
        try:
            os.makedirs(out_dir, exist_ok=True)
        except Exception:
            pass
        ts = time.strftime("%Y%m%d_%H%M%S")
        ms = int(time.time() * 1000) % 1000
        path = os.path.join(out_dir, f"drawing_{ts}_{ms:03d}.png")
        self.context.write_file(path, raw_bytes)
        return path

    # ---------- 动作 ----------

    def _action_save(self, payload):
        try:
            raw = self._decode_image(payload)
            path = self._save_png(raw)
            self.context.notify("success", "画画板", f"已保存：{path}")
            return {"ok": True, "path": path}
        except Exception as e:
            self.context.log(f"[paintboard] 保存失败：{e}")
            self.context.notify("error", "画画板", f"保存失败：{e}")
            return {"ok": False, "error": str(e)}

    def _action_add_to_chat(self, payload):
        try:
            raw = self._decode_image(payload)
            path = self._save_png(raw)
            prompt = f"用户刚刚在画板里画了一张图，已保存到：{path}\n请查看并回应。"
            self.context.dispatch_task(
                prompt, meta={"source": PLUGIN_ID, "image_path": path}
            )
            self.context.notify("success", "画画板", "已添加到对话")
            return {"ok": True, "path": path}
        except Exception as e:
            self.context.log(f"[paintboard] 添加到对话失败：{e}")
            self.context.notify("error", "画画板", f"添加到对话失败：{e}")
            return {"ok": False, "error": str(e)}


PANEL_HTML = r"""<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<style>
  * { box-sizing: border-box; }
  html, body { margin: 0; padding: 0; height: 100%; overflow: hidden;
               font-family: -apple-system, "Segoe UI", "Microsoft YaHei", sans-serif; }
  #pb-root { display: flex; flex-direction: column; height: 100%; background: #fafafa; }
  .pb-toolbar { display: flex; flex-wrap: wrap; gap: 6px; align-items: center;
                padding: 8px; background: #fff; border-bottom: 1px solid #e0e0e0; }
  .pb-toolbar input[type="color"] { width: 36px; height: 32px; padding: 2px;
                border: 1px solid #ccc; border-radius: 4px; background: #fff; cursor: pointer; }
  .pb-toolbar input[type="range"] { width: 90px; }
  .pb-btn { padding: 6px 12px; border: 1px solid #d0d0d0; background: #fff;
            border-radius: 4px; cursor: pointer; font-size: 13px; color: #333; }
  .pb-btn:hover { background: #f5f5f5; }
  .pb-btn.active { background: #ffe6c7; border-color: #ff9800; }
  .pb-btn.primary { background: #4a90d9; color: #fff; border-color: #4a90d9; }
  .pb-btn.primary:hover { background: #3a7cc4; }
  .pb-btn.success { background: #3aa76d; color: #fff; border-color: #3aa76d; }
  .pb-btn.success:hover { background: #2e9460; }
  .pb-canvas-wrap { flex: 1; position: relative; overflow: hidden; background: #fff; }
  #pb-canvas { display: block; cursor: crosshair; touch-action: none; }
  #pb-status { padding: 5px 10px; font-size: 12px; color: #888; background: #fafafa;
               border-top: 1px solid #e0e0e0; min-height: 22px; }
  .pb-size-label { font-size: 12px; color: #666; min-width: 20px; text-align: center; }
</style>
</head>
<body>
<div id="pb-root">
  <div class="pb-toolbar">
    <input type="color" id="pb-color" value="#000000" title="画笔颜色">
    <input type="range" id="pb-size" min="1" max="40" value="4" title="笔刷大小">
    <span class="pb-size-label" id="pb-size-val">4</span>
    <button class="pb-btn" id="pb-eraser" title="切换橡皮擦">橡皮</button>
    <button class="pb-btn" id="pb-undo" title="撤销">撤销</button>
    <button class="pb-btn" id="pb-clear" title="清空画布">清空</button>
    <span style="flex:1;"></span>
    <button class="pb-btn primary" id="pb-save" title="保存为 PNG">保存 PNG</button>
    <button class="pb-btn success" id="pb-chat" title="保存并发送到对话">添加到对话</button>
  </div>
  <div class="pb-canvas-wrap" id="pb-canvas-wrap">
    <canvas id="pb-canvas"></canvas>
  </div>
  <div id="pb-status">就绪</div>
</div>
<script>
(function () {
  'use strict';
  var PLUGIN_ID = 'com.yourname.paintboard';

  var canvas     = document.getElementById('pb-canvas');
  var ctx        = canvas.getContext('2d');
  var wrap       = document.getElementById('pb-canvas-wrap');
  var colorInput = document.getElementById('pb-color');
  var sizeInput  = document.getElementById('pb-size');
  var sizeVal    = document.getElementById('pb-size-val');
  var eraserBtn  = document.getElementById('pb-eraser');
  var undoBtn    = document.getElementById('pb-undo');
  var clearBtn   = document.getElementById('pb-clear');
  var saveBtn    = document.getElementById('pb-save');
  var chatBtn    = document.getElementById('pb-chat');
  var statusEl   = document.getElementById('pb-status');

  var drawing = false;
  var lastX = 0, lastY = 0;
  var eraser = false;
  var history = [];
  var MAX_HISTORY = 30;

  function setStatus(msg) { statusEl.textContent = msg; }

  // ---------- 与宿主通信 ----------
  function getLZ() {
    if (typeof LZ !== 'undefined' && LZ && LZ.plugins) return LZ;
    try {
      if (window.parent && window.parent.LZ && window.parent.LZ.plugins) return window.parent.LZ;
    } catch (e) {}
    return null;
  }

  function invoke(action, payload) {
    var lz = getLZ();
    if (!lz) {
      setStatus('无法连接到应用（LZ.plugins 不可用）');
      return Promise.reject(new Error('LZ.plugins 不可用'));
    }
    try {
      return Promise.resolve(lz.plugins.invoke(PLUGIN_ID, action, payload));
    } catch (e) {
      return Promise.reject(e);
    }
  }

  // ---------- 画布尺寸 ----------
  function resizeCanvas() {
    var rect = wrap.getBoundingClientRect();
    var w = Math.max(100, Math.floor(rect.width));
    var h = Math.max(100, Math.floor(rect.height));
    if (w === canvas.width && h === canvas.height) return;

    var backup = null;
    if (canvas.width > 0 && canvas.height > 0) {
      backup = document.createElement('canvas');
      backup.width = canvas.width;
      backup.height = canvas.height;
      backup.getContext('2d').drawImage(canvas, 0, 0);
    }

    canvas.width = w;
    canvas.height = h;
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, w, h);
    if (backup) ctx.drawImage(backup, 0, 0);
  }

  // ---------- 坐标与绘制 ----------
  function getPos(e) {
    var rect = canvas.getBoundingClientRect();
    var sx = canvas.width / rect.width;
    var sy = canvas.height / rect.height;
    var t = (e.touches && e.touches[0]) ? e.touches[0] : e;
    return { x: (t.clientX - rect.left) * sx, y: (t.clientY - rect.top) * sy };
  }

  function beginStroke(e) {
    e.preventDefault();
    drawing = true;
    var p = getPos(e);
    lastX = p.x; lastY = p.y;
    pushHistory();
    drawDot(p.x, p.y);
  }

  function continueStroke(e) {
    if (!drawing) return;
    e.preventDefault();
    var p = getPos(e);
    drawSegment(lastX, lastY, p.x, p.y);
    lastX = p.x; lastY = p.y;
  }

  function endStroke(e) {
    if (!drawing) return;
    if (e && e.preventDefault) e.preventDefault();
    drawing = false;
  }

  function strokeStyle() {
    var s = parseInt(sizeInput.value, 10) || 4;
    return {
      color: eraser ? '#ffffff' : colorInput.value,
      width: eraser ? Math.max(24, s * 4) : s
    };
  }

  function drawDot(x, y) {
    var s = strokeStyle();
    ctx.beginPath();
    ctx.arc(x, y, s.width / 2, 0, Math.PI * 2);
    ctx.fillStyle = s.color;
    ctx.fill();
  }

  function drawSegment(x1, y1, x2, y2) {
    var s = strokeStyle();
    ctx.beginPath();
    ctx.moveTo(x1, y1);
    ctx.lineTo(x2, y2);
    ctx.lineWidth = s.width;
    ctx.strokeStyle = s.color;
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
    ctx.stroke();
  }

  // ---------- 历史 / 撤销 ----------
  function pushHistory() {
    try {
      history.push(canvas.toDataURL('image/png'));
      if (history.length > MAX_HISTORY) history.shift();
    } catch (e) {}
  }

  function restoreFromDataUrl(dataUrl) {
    return new Promise(function (resolve) {
      var img = new Image();
      img.onload = function () {
        ctx.fillStyle = '#ffffff';
        ctx.fillRect(0, 0, canvas.width, canvas.height);
        ctx.drawImage(img, 0, 0);
        resolve();
      };
      img.onerror = function () { resolve(); };
      img.src = dataUrl;
    });
  }

  function undo() {
    if (!history.length) { setStatus('没有可撤销的操作'); return; }
    var data = history.pop();
    restoreFromDataUrl(data).then(function () { setStatus('已撤销'); });
  }

  function clearAll() {
    pushHistory();
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    setStatus('已清空');
  }

  // ---------- 动作 ----------
  function currentPngDataUrl() {
    return canvas.toDataURL('image/png');
  }

  function doSave() {
    setStatus('保存中...');
    return invoke('save', { dataUrl: currentPngDataUrl() }).then(function (res) {
      if (res && res.ok) setStatus('已保存：' + res.path);
      else setStatus('保存失败：' + ((res && res.error) || '未知错误'));
    }).catch(function (err) { setStatus('保存失败：' + err); });
  }

  function doAddToChat() {
    setStatus('发送中...');
    return invoke('add_to_chat', { dataUrl: currentPngDataUrl() }).then(function (res) {
      if (res && res.ok) setStatus('已添加到对话：' + res.path);
      else setStatus('发送失败：' + ((res && res.error) || '未知错误'));
    }).catch(function (err) { setStatus('发送失败：' + err); });
  }

  // ---------- 事件绑定 ----------
  canvas.addEventListener('mousedown', beginStroke);
  canvas.addEventListener('mousemove', continueStroke);
  window.addEventListener('mouseup', endStroke);
  canvas.addEventListener('touchstart', beginStroke, { passive: false });
  canvas.addEventListener('touchmove', continueStroke, { passive: false });
  canvas.addEventListener('touchend', endStroke, { passive: false });
  canvas.addEventListener('touchcancel', endStroke, { passive: false });

  sizeInput.addEventListener('input', function () {
    sizeVal.textContent = sizeInput.value;
  });

  eraserBtn.addEventListener('click', function () {
    eraser = !eraser;
    eraserBtn.classList.toggle('active', eraser);
    setStatus(eraser ? '橡皮模式' : '画笔模式');
  });

  undoBtn.addEventListener('click', undo);
  clearBtn.addEventListener('click', clearAll);
  saveBtn.addEventListener('click', doSave);
  chatBtn.addEventListener('click', doAddToChat);

  document.addEventListener('keydown', function (e) {
    if ((e.ctrlKey || e.metaKey) && (e.key === 'z' || e.key === 'Z')) {
      e.preventDefault();
      undo();
    }
  });

  // ---------- 初始化 ----------
  setTimeout(function () {
    resizeCanvas();
    if (window.ResizeObserver) {
      new ResizeObserver(function () { resizeCanvas(); }).observe(wrap);
    } else {
      window.addEventListener('resize', resizeCanvas);
    }
  }, 50);
})();
</script>
</body>
</html>
"""